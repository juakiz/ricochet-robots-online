var util = require('util');
var BattleLogic = require('../server/battle-logic/main-logic.js');

var MAX_ROOM_USERS = 2;

var rooms = {
  // random: {},
  // custom: {},
};
var lastUserId = 0;
var lastRoomId = 1000;
var lastRoomName = '';

var MessageType = {
  // Messages you send to server, when want to join or leave etc.
  JOIN: 'join-room',
  LEAVE: 'leave-room',
  DISCONNECT: 'disconnect',

  // You receive room info as a response for join command. It contains information about
  // the room you joined, and it's users
  ROOM: 'room',

  // A messages you receive from server when another user want to join or leave etc.
  USER_JOIN: 'user_join',
  USER_READY: 'user_ready',
  USER_LEAVE: 'user_leave',

  // Errors... shit happens
  ERROR_ROOM_IS_FULL: 'error_room_is_full',
  ERROR_USER_INITIALIZED: 'error_user_initialized',

  // Gameplay
  SPAWN_UNIT: 'spawn-unit',
};

function User(unitData) {
  this.userId = ++lastUserId;
  this.unitData = unitData;
}
User.prototype = {
  getId: function () {
    return this.userId;
  }
};


function Room(name) {
  this.roomName = name;
  this.users = [];
  this.sockets = {};
  this.interval = null;
}
Room.prototype = {
  getName: function () {
    return this.roomName;
  },
  getUsers: function () {
    return this.users;
  },
  getUserById: function (id) {
    return this.users.find(function (user) {
      return user.getId() === id;
    });
  },
  numUsers: function () {
    return this.users.length;
  },
  isEmpty: function () {
    return this.users.length === 0;
  },
  isFull: function () {
    return this.users.length === MAX_ROOM_USERS;
  },
  addUser: function (user, socket) {
    this.users.push(user);
    this.sockets[user.getId()] = socket;
  },
  removeUser: function (id) {
    this.users = this.users.filter(function (user) {
      return user.getId() !== id;
    });
    delete this.sockets[id];
  },
  sendTo: function (user, message, data) {
    var socket = this.sockets[user.getId()];
    if (message != 'game-tick') {
      console.log(socket.id, message, JSON.stringify(data));
    }
    socket.emit(message, data);
  },
  sendToId: function (userId, message, data) {
    return this.sendTo(this.getUserById(userId), message, data);
  },
  broadcastFrom: function (fromUser, message, data) {
    this.users.forEach(function (user) {
      if (user.getId() !== fromUser.getId()) {
        this.sendTo(user, message, data);
      }
    }, this);
  },
  sendToAll: function (message, data) {
    this.users.forEach(function (user) {
      this.sendTo(user, message, data);
    }, this);
  },
  startGame: function () {
    const _this = this;

    // Tell each user which index they are (*maybe do this better later)
    // this.sendTo(this.users[0], 'indextify', 0);
    // this.sendTo(this.users[1], 'indextify', 1);
    // console.log(/* userId,  */JSON.stringify(this.users[0]));

    const usersData = [
      { id: this.users[0].getId(), units: this.users[0].unitData },
      { id: this.users[1].getId(), units: this.users[1].unitData },
    ];
    this.battle = new BattleLogic(usersData);
    this.inverval = setInterval(() => {
      const tick = this.battle.update.call(this.battle);
      _this.sendToAll('game-tick', tick);

      // stop sending ticks if someone won
      if (this.battle.status === 0 || this.battle.status === 1) {
        _this.stopGame();
      }
    }, 100/* , this.battle */);
  },
  stopGame: function () {
    clearInterval(this.inverval);
  },
  pauseGame: function () {
    this.battle.pause();
  },
  spawnUnit: function (unit, userIndex) {
    // console.log(/* userId,  */JSON.stringify(this.users));
    // const userIndex = userId === this.users[0].userId ? 0 : 1;
    this.battle.spawn(unit, userIndex);
  }
};

module.exports = function (socket) {
  console.log('[server.js]: A user connected.');

  // console.log(util.inspect(socket));

  // socket.on('disconnect', function () {
  //   console.log('[server.js]: User disconnected.');
  // });

  // socket.on('join-room', function (roomName) {
  //   socket.join(roomName);
  // });

  // socket.on('update-game', function (myUnitPos) {
  //   socket.broadcast.emit('receive-game', myUnitPos);
  //   // console.log('Tick:' + number);
  // });

  var user = null;
  var room = null;

  socket.on(MessageType.JOIN, onJoin);
  socket.on(MessageType.DISCONNECT, onDisconnect);
  socket.on(MessageType.LEAVE, onLeave);

  socket.on(MessageType.SPAWN_UNIT, onSpawnUnit);

  function onJoin(joinData) {
    console.log('[server.js]: A user tried to join...');

    // Somehow sent join request twice?
    if (/* user !== null ||  */room !== null) {
      console.log('[server.js]: User tried to join room twice!');
      room.sendTo(user, MessageType.ERROR_USER_INITIALIZED);
      return;
    }

    // Let's get a room, or create if none still exists
    room = getOrCreateRoom(joinData.roomName);
    if (room.numUsers() >= MAX_ROOM_USERS) { // an user is trying
      room.sendTo(user, MessageType.ERROR_ROOM_IS_FULL);
      console.log(user);// testing purposes
      return;
    }

    // Add a new user
    room.addUser(user = new User(joinData.unitData), socket);

    // Send room info to new user
    room.sendTo(user, MessageType.ROOM, {
      userId: user.getId(),
      roomName: room.getName(),
      users: room.getUsers()
    });
    // Notify others of a new user joined
    room.broadcastFrom(user, MessageType.USER_JOIN, {
      userId: user.getId(),
      users: room.getUsers()
    });
    console.log('User %s joined room %s. Users in room: %d',
      user.getId(), room.getName(), room.numUsers());
    if (room.isFull()) {
      console.log('Matched for a game between User %d and User %d!',
        room.users[0].getId(), room.users[1].getId());
      // room.sendToAll('start-game');
      room.sendTo(room.users[0], 'start-game', 0);
      room.sendTo(room.users[1], 'start-game', 1);
      room.startGame();
    }
  }

  function getOrCreateRoom(name) {
    var room;
    if (!name) {
      name = lastRoomId + '_room';
    }
    if (!rooms[name] || rooms[name].isFull()) {
      name = ++lastRoomId + '_room';
      room = new Room(name);
      rooms[name] = room;
    }
    return rooms[name];
  }

  function removeUser() {
    room.removeUser(user.getId());
    console.log('User %d left room %s. Users in room: %d',
      user.getId(), room.getName(), room.numUsers());
    if (room.isEmpty()) {
      console.log('Room is empty - dropping room %s', room.getName());
      delete rooms[room.getName()];
      room.stopGame();
    }
    room.broadcastFrom(user, MessageType.USER_LEAVE, {
      userId: user.getId()
    });
  }

  function onDisconnect() {
    console.log('[server.js]: User disconnected.');
    if (room === null) {
      return;
    }
    removeUser();
  }

  function onLeave() {
    if (room === null) {
      return;
    }
    removeUser();
    room = null;
  }

  function onSpawnUnit(unit, userIndex) {
    room.spawnUnit(unit, userIndex);
  }
};

// This file will be called when a user starts the game, however we still need to
// subscribe events related to join a game. the event will be fired at press fight button
// A game will be developed in rooms.
// A specific room in case the game mode chosen is "invite a friend"
// or not specific a for solo game,
// in that case check if some room is occupied by a waiting user,
// otherwise create an empty one and add the user.

// Once users are matched, game starts.
// the logic of the game will be placed in the server.
// the system will be based on a "tick analizer"
// what takes a game state and send results to clients in order to visualize
// clients will render the information sent by the server,
// but also send events when the user creates a unit,
// and that will be the only type of user interaction.

// Server will analyze the current tick-game-state and
// send next unit and rock data to users.
// -------- think about fight issues when the moment arrives --------
// The thing I'm worried about are how to handle attack animations.
// Maybe some type of delay handling... will see.

// TODO:
// * handle events between server and client. (connection, rooming, gameplay and disconnections)
// * split (or remake) game logic into visualization and logic
// to split into server and client code.