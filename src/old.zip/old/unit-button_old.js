
export default class UnitButton extends Phaser.GameObjects.Image {
  constructor(parent, asset, inputKey, sign, index) {
    super(parent.scene, 0, 0, 'atlas', `${asset}/${asset}_portrait.png`);
    parent.scene.add.existing(this);
    parent.add(this);
    this._main = parent._main;

    // console.log(asset);

    this.asset = asset;
    this.inputKey = inputKey;
    this.index = index;

    if (sign === 1) this.flipX = true;

    this.init(sign);
  }

  init(sign) {
    const { index, asset, inputKey, _main } = this;

    this.setInteractive().on('pointerdown', function (pointer, localX, localY, event) {
      // _main.spawnUnit(asset, sign);
      this.scene.events.emit('spawn-unit', index);
    });

    var keyObj = this.scene.input.keyboard.addKey(inputKey);
    keyObj.on('down', (event) => {
      // _main.spawnUnit(asset, sign);
      this.scene.events.emit('spawn-unit', index);
    }, this);
  }
}
