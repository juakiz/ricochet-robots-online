import { UnitInfo } from "../../js/scenes/system/game-info";

const HALF_ROCK_LENGTH = 531;

const DYING = -1;
const NOTHING = 0;
const ATTACKING = 1;
const WALKING = 2;

export default class Unit extends Phaser.GameObjects.Sprite {
  constructor(parent, asset, side) {
    super(parent.scene, 0, 0, asset, 0);
    parent.scene.add.existing(this);
    parent.add(this);

    this.asset = asset;

    if (asset.includes('cat'))
      this.setOrigin(0.5, 0.75);
    else
      this.setOrigin(0.5, 1);

    this.type = UnitInfo[asset];
    this.spd = this.type.spd;
    this.side = side;
    if (this.side === 1) this.flipX = true;

    this.UID = ++parent.unitCounter;

    this.hp = this.totalHp = this.type.hp;
    this.rng = this.type.rng;
    // if (this.type.scale) this.setScale(this.type.scale);
    this.setScale(4);

    this.piedra = parent.rock;

    this.x = (HALF_ROCK_LENGTH - 60) * this.side;
    this.y = -65;

    const units = parent.units;
    this.enemies = units[`${this.side * -1}`];
    this.allies = units[`${this.side}`];
    units[`${this.side}`].push(this);

    this.baseWeight = this.hp;

    this.currentAction = NOTHING;

    this.target = null;

    // this.on(`animationupdate-${asset}-walk`, this.updateWalking, this);

    // console.log ("I'm " , this.unit);
    this.playWalk();
    this.createHpBar();
  }

  createHpBar() {
    var hpBarBg = this.hpBarBg = this.scene.add.graphics();
    hpBarBg.setPosition(this.x, this.y);
    hpBarBg.fillStyle(0xff0000, 1);
    hpBarBg.fillRect(-this.totalHp * 5 / 2, -this.displayHeight, this.totalHp * 5, 10);
    this.parentContainer.add(hpBarBg);


    var hpBar = this.hpBar = this.scene.add.graphics();
    hpBar.setPosition(this.x, this.y);
    hpBar.fillStyle(0x00ff00, 1);
    hpBar.fillRect(-this.totalHp * 5 / 2, -this.displayHeight, this.totalHp * 5, 10);
    this.parentContainer.add(hpBar);
  }

  modHpBar() {
    const { hpBar, hp, totalHp } = this;
    const percent = Math.max(hp, 0) / totalHp;
    hpBar.clear();
    hpBar.fillStyle(0x00FF00, 1);
    hpBar.fillRect(-this.totalHp * 5 / 2, -this.displayHeight, this.totalHp * 5 * percent, 10);
  }

  playWalk() {
    this.play(`${this.asset}-walk`);
    this.currentAction = WALKING;
  }

  playAttack() {
    this.play(`${this.asset}-attack`);
    this.currentAction = ATTACKING;
  }

  // Main method
  perform() {
    // if the unit is already attacking a target, keep attacking until target dies (if it is in rng)
    if (this.target && Math.abs(this.x - this.target.x) <= this.rng) {
      // dont set the attack if the unit is already permorming an attack
      if (this.currentAction !== ATTACKING) {
        this.attack(this.target);
      }
    }
    // otherwise check if there is a target in rng to decide if attack or keep walking
    else {
      const target = this.checkEnemyDistances(this.enemies);
      if (!target)
        this.move();
      else
        this.attack(target);
    }
  }

  checkReachingBorder() {
    if (Math.abs(this.x) > HALF_ROCK_LENGTH) {
      // if we pause the animation also pause movement
      this.anims.stop();
      this.scene.events.emit('player-win', this.side);
    }
  }

  // phase 1, return null or an unit in rng
  checkEnemyDistances(enemiesArray) {
    for (let en of enemiesArray) {
      const distance = Math.abs(this.x - en.x);
      console.log(this.asset + distance);
      if (distance <= this.rng)
        return en;
    }
    return null;
  }

  // phase 2, A
  move() {
    this.x -= this.spd * this.side * 2;
    this.hpBar.x = this.x;
    this.hpBarBg.x = this.x;

    // Game ends when unit reach rock border too
    this.checkReachingBorder();
  }

  // phase 2, B
  attack(target) {
    this.target = target;
    target.aggressor = this;

    this.playAttack();

    this.once(`animationcomplete-${this.asset}-attack`, () => {
      // deal the damage
      target.hp -= this.type.dmg;
      console.log('Attacked Unit: ' + target.asset + ', ' + 'Hp: ' + target.hp);
      // if (target.hp <= 0) {
      this.playWalk();
      // } else {
      //   this.attack(target);
      // }

      target.modHpBar();
    }, this);
  }

  // phase 3
  setDeath() {
    this.aggressor.target = null;
    for (let i = 0; i < this.allies.length; i++)
      if (this.allies[i].UID == this.UID)
        this.allies.splice(i, 1);
    this.destroy();
    this.hpBar.destroy();
    this.hpBarBg.destroy();
  }

  unitFall() {
    // Maybe there are better ways to transform rotated childrens to parent container...
    const offsetAngle = Math.atan2(this.y, this.x);
    const vectorMod = Math.sqrt(this.x * this.x + this.y * this.y);
    this.x = this.parentContainer.x + Math.cos(this.parentContainer.rotation + offsetAngle) * vectorMod;
    this.y = this.parentContainer.y + Math.sin(this.parentContainer.rotation + offsetAngle) * vectorMod;
    this.angle = this.parentContainer.angle;
    this.parentContainer.parentContainer.add(this);
    console.log(this.UID);
    this.scene.tweens.add({
      targets: this,
      x: Math.random() * this._main.TOTAL_WIDTH + this._main.LEFT,
      y: Math.random() * this._main.TOTAL_HEIGHT + this._main.TOP,
      angle: 720,
      // ease: 'Quad.easeIn',
      duration: 900,
      onComplete: () => { this.destroy(); },
      onCompleteScope: this,
    });
  }

  getWeight() {
    return this.baseWeight * Math.abs(this.x / HALF_ROCK_LENGTH) * 2;
  }

  stopWalk() {
    this.spd = 0;
  }
}
