import Unit from "./unit";
// const socket = io();
let COUNT = 0;

export default class Rock extends Phaser.GameObjects.Container {
  constructor(parent) {
    super(parent.scene);

    this.name = 'Rock';

    parent.add(this);
    this._main = parent._main;

    this.scene.events.once('player-win', this.rockFall, this);

    this.x = this._main.CENTER_X;
    this.y = this._main.INNER_HEIGHT - parent.base.displayHeight;

    this.units = {
      '-1': [], // left
      '1': [], // right
    };

    this.unitCounter = 0;

    // socket.on('receive-game', function (msg) {
    //   console.log(msg);
    // });

    this.init();
  }

  init() {
    const rock = this.rock = this.scene.add.image(0, 40, 'atlas', 'base_piedra.png');
    rock.setScale(4);
    rock.setOrigin(0.5, 1);
    this.add(rock);
    console.log(`Rock width: ${rock.displayWidth}`);
  }

  // Gameplay methods
  spawnUnit(asset, side) {
    new Unit(this, asset, side);
  }

  moveUnits() {
    this.units['1'].forEach((value, index, array) => {
      value.perform();
    });
    this.units['-1'].forEach((value, index, array) => {
      value.perform();
    });
  }

  checkDeath() {
    this.units['1'].forEach((value, index, array) => {
      if (value.hp <= 0)
        value.setDeath();
    });
    this.units['-1'].forEach((value, index, array) => {
      if (value.hp <= 0)
        value.setDeath();
    });
  }

  setLeftWeight(amount) {
    this.leftWeight += amount;
  }

  setRightWeight(amount) {
    this.rightWeight += amount;
  }

  setBalance() {
    this.balance = 0;

    this.getSideWeight(this.units['-1']);
    this.getSideWeight(this.units['1']);

    this.angle = Phaser.Math.Linear(this.angle, this.balance, 0.04);

    if (this.angle > 40)
      this.scene.events.emit('player-win', -1);
    else if (this.angle < -40)
      this.scene.events.emit('player-win', 1);
  }

  getSideWeight(side) {
    side.forEach(el => {
      if (el.x < 0)
        this.balance -= el.getWeight();
      else
        this.balance += el.getWeight();
      // this.balance = el.x < 0 ? this.balance - el.getWeight() : this.balance + el.getWeight();
    });
  }

  rockFall(winner) {
    this.scene.tweens.add({
      targets: [this, this._main.base],
      y: 1600,
      ease: 'Quad.easeIn',
      duration: 1000,
    });
    console.log('the winner is ' + winner);
  }

  update() {
    // this.moveUnits();
    this.setBalance();
  }

  syncUpdate() {
    console.log('-------');
    this.moveUnits();
    // socket.emit('update-game', 'myUnitPos');
    this.checkDeath();
    // this.setBalance();
  }

  // Layouting methods
  resize() {
    const { _main } = this;
  }
}
