
const HALF_ROCK_LENGTH = 531;

export default class Unit extends Phaser.GameObjects.Sprite {
  constructor(parent, asset) {
    super(parent.scene, 0, 0, asset, 0);
    parent.scene.add.existing(this);
    parent.add(this);

    this.asset = asset;

    this.setOrigin(0.5, 1);

    this.type = Unit.OBJ_UNIT_INFO[asset];
    this.spd = this.type.spd;
    this.side = this.type.side;
    if (this.side === 1) this.flipX = true;

    this.UID = ++parent.unitCounter;

    this.hp = this.totalHp = this.type.hp;
    this.rng = this.type.rng;
    if (this.type.scale) this.setScale(this.type.scale);

    this.piedra = parent.rock;

    this.x = (HALF_ROCK_LENGTH - 60) * this.side;
    this.y = -65;

    const units = parent.units;
    this.enemies = units[`${this.side * -1}`];
    this.allies = units[`${this.side}`];
    units[`${this.side}`].push(this);

    this.baseWeight = this.hp;

    this.on(`animationupdate-${asset}-walk`, this.updateWalking, this);

    // console.log ("I'm " , this.unit);
    this.walk();
    this.createHpBar();
  }

  createHpBar() {
    var hpBarBg = this.hpBarBg = this.scene.add.graphics();
    hpBarBg.setPosition(this.x, this.y);
    hpBarBg.fillStyle(0xff0000, 1);
    hpBarBg.fillRect(-this.totalHp * 5 / 2, -this.displayHeight, this.totalHp * 5, 10);
    this.parentContainer.add(hpBarBg);


    var hpBar = this.hpBar = this.scene.add.graphics();
    hpBar.setPosition(this.x, this.y);
    hpBar.fillStyle(0x00ff00, 1);
    hpBar.fillRect(-this.totalHp * 5 / 2, -this.displayHeight, this.totalHp * 5, 10);
    this.parentContainer.add(hpBar);
  }

  modHpBar() {
    const { hpBar, hp, totalHp } = this;
    const percent = hp / totalHp;
    hpBar.clear();
    hpBar.fillStyle(0x00FF00, 1);
    hpBar.fillRect(-this.totalHp * 5 / 2, -this.displayHeight, this.totalHp * 5 * percent, 10);
  }

  walk() {
    // console.log(`${this.asset}-walk`);
    this.play(`${this.asset}-walk`);
  }

  updateWalking() {
    let target = this.checkEnemyDistances(this.enemies);
    if (!target) {
      this.x -= this.spd * this.side;
      this.hpBar.x = this.x;
      this.hpBarBg.x = this.x;
    } else
      this.attack(target);

    // Game ends when unit reach rock border too
    if (Math.abs(this.x) > HALF_ROCK_LENGTH) {
      // if we pause the animation also pause movement
      this.anims.stop();
      this.scene.events.emit('player-win', this.side);
    }
  }

  checkEnemyDistances(enemiesArray) {
    for (let en of enemiesArray) {
      if (Math.abs(this.x - en.x) <= this.rng)
        return en;
    }
    return null;
  }

  attack(target) {
    let exist = false;
    for (let i = 0; i < this.enemies.length; i++) {
      // console.log(this.enemies[i].UID, target.UID);
      if (this.enemies[i].UID == target.UID)
        exist = true;
    }

    if (exist) {
      this.play(`${this.asset}-attack`);

      this.once(`animationcomplete-${this.asset}-attack`, () => {
        target.modHP(this.type.dmg);
        this.attack(target);
      }, this);
    }
    else {
      this.walk();
    }
  }

  modHP(amount) {
    this.hp -= amount;
    if (this.hp <= 0) {
      for (let i = 0; i < this.allies.length; i++)
        if (this.allies[i].UID == this.UID)
          this.allies.splice(i, 1);
      this.destroy();
      this.hpBar.destroy();
      this.hpBarBg.destroy();
    }

    this.modHpBar();
  }

  getWeight() {
    return this.baseWeight * Math.abs(this.x / HALF_ROCK_LENGTH) * 2;
  }

  stopWalk() {
    this.spd = 0;
  }
}

// UNIT INFO OBJECT
// NOTE: we use the "side" values to multiply positions in order to get mirrored positions
Unit.OBJ_UNIT_INFO = {
  knight_m: { side: -1, spd: 2, dmg: 5, hp: 20, rng: 60, scale: 4 },
  wizzard_m: { side: -1, spd: 4, dmg: 4, hp: 15, rng: 45, scale: 4 },
  elf_m: { side: -1, spd: 6, dmg: 2, hp: 10, rng: 30, scale: 4 },

  knight_f: { side: -1, spd: 2, dmg: 5, hp: 20, rng: 60, scale: 4 },
  wizzard_f: { side: -1, spd: 4, dmg: 4, hp: 15, rng: 45, scale: 4 },
  elf_f: { side: -1, spd: 6, dmg: 2, hp: 10, rng: 30, scale: 4 },

  big_zombie: { side: -1, spd: 2, dmg: 5, hp: 20, rng: 60, scale: 4 },
  zombie: { side: -1, spd: 4, dmg: 4, hp: 15, rng: 45, scale: 4 },
  tiny_zombie: { side: -1, spd: 6, dmg: 2, hp: 10, rng: 30, scale: 4 },

  ogre: { side: 1, spd: 2, dmg: 5, hp: 20, rng: 60, scale: 4 },
  orc_warrior: { side: 1, spd: 4, dmg: 4, hp: 15, rng: 45, scale: 4 },
  goblin: { side: 1, spd: 6, dmg: 2, hp: 10, rng: 30, scale: 4 },

  big_demon: { side: 1, spd: 2, dmg: 5, hp: 20, rng: 60, scale: 4 },
  chort: { side: 1, spd: 4, dmg: 4, hp: 15, rng: 45, scale: 4 },
  imp: { side: 1, spd: 6, dmg: 2, hp: 10, rng: 30, scale: 4 },

  necromancer: { side: 1, spd: 2, dmg: 5, hp: 20, rng: 60, scale: 4 },
  masked_orc: { side: 1, spd: 4, dmg: 4, hp: 15, rng: 45, scale: 4 },
  skelet: { side: 1, spd: 6, dmg: 2, hp: 10, rng: 30, scale: 4 },
};
